import SwiftUI

@main
struct SOAPNotesApp: App {
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            if appState.isUnlocked {
                MainTabView()
                    .environmentObject(appState)
                    .onReceive(NotificationCenter.default.publisher(for: UIApplication.willResignActiveNotification)) { _ in
                        appState.saveNote()
                    }
            } else {
                LockScreenView()
                    .environmentObject(appState)
            }
        }
    }
}
