import SwiftUI

struct LockScreenView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.indigo, Color.purple]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            VStack(spacing: 30) {
                Spacer()
                
                Image(systemName: "doc.text.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.white)
                
                Text("SOAP Notes")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Text("HIPAA-Compliant Documentation")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.8))
                
                Spacer()
                
                VStack(spacing: 16) {
                    Button(action: {
                        appState.authenticate()
                    }) {
                        HStack {
                            Image(systemName: "faceid")
                                .font(.title2)
                            Text("Unlock with Face ID")
                                .fontWeight(.semibold)
                        }
                        .foregroundColor(.indigo)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(12)
                    }
                    .padding(.horizontal, 40)
                    
                    HStack(spacing: 4) {
                        Image(systemName: "lock.shield.fill")
                            .font(.caption)
                        Text("Data stored locally with encryption")
                            .font(.caption)
                    }
                    .foregroundColor(.white.opacity(0.7))
                }
                
                Spacer()
                
                VStack(spacing: 8) {
                    HStack(spacing: 4) {
                        Image(systemName: "checkmark.shield.fill")
                            .foregroundColor(.green)
                        Text("On-device speech recognition")
                    }
                    HStack(spacing: 4) {
                        Image(systemName: "checkmark.shield.fill")
                            .foregroundColor(.green)
                        Text("No cloud storage")
                    }
                    HStack(spacing: 4) {
                        Image(systemName: "checkmark.shield.fill")
                            .foregroundColor(.green)
                        Text("Keychain encryption")
                    }
                }
                .font(.caption)
                .foregroundColor(.white.opacity(0.8))
                .padding(.bottom, 30)
            }
        }
        .onAppear {
            // Auto-trigger Face ID on appear
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                appState.authenticate()
            }
        }
    }
}
