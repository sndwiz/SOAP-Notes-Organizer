import SwiftUI

struct MainTabView: View {
    @EnvironmentObject var appState: AppState
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            SessionInfoView()
                .tabItem {
                    Image(systemName: "person.text.rectangle")
                    Text("Session")
                }
                .tag(0)
            
            SOAPFormView()
                .tabItem {
                    Image(systemName: "doc.text")
                    Text("SOAP")
                }
                .tag(1)
            
            AssessmentsView()
                .tabItem {
                    Image(systemName: "chart.bar.doc.horizontal")
                    Text("Measures")
                }
                .tag(2)
            
            RiskAssessmentView()
                .tabItem {
                    Image(systemName: "exclamationmark.shield")
                    Text("Risk")
                }
                .tag(3)
            
            ExportView()
                .tabItem {
                    Image(systemName: "square.and.arrow.up")
                    Text("Export")
                }
                .tag(4)
        }
        .accentColor(.indigo)
        .onChange(of: selectedTab) { _ in
            appState.saveNote()
        }
    }
}
