import Foundation

// MARK: - Main SOAP Note Model
struct SOAPNote: Codable {
    var sessionInfo: SessionInfo = SessionInfo()
    var subjective: String = ""
    var objective: String = ""
    var assessment: String = ""
    var plan: String = ""
    var phq9: AssessmentScore = AssessmentScore(type: .phq9)
    var gad7: AssessmentScore = AssessmentScore(type: .gad7)
    var riskAssessment: RiskAssessment = RiskAssessment()
    var lastModified: Date = Date()
}

// MARK: - Session Info
struct SessionInfo: Codable {
    var clientName: String = ""
    var clientDOB: Date = Date()
    var providerName: String = ""
    var sessionDate: Date = Date()
    var startTime: Date = Date()
    var endTime: Date = Date()
    var location: String = "Office"
    var isTelehealth: Bool = false
    var cptCode: String = "90837"
    var diagnoses: [Diagnosis] = []
}

// MARK: - Diagnosis
struct Diagnosis: Codable, Identifiable, Hashable {
    var id = UUID()
    var code: String
    var name: String
}

// MARK: - Assessment Scores
struct AssessmentScore: Codable {
    var type: AssessmentType
    var items: [Int]
    var date: Date = Date()
    
    var total: Int {
        items.reduce(0, +)
    }
    
    var severity: String {
        switch type {
        case .phq9:
            if total <= 4 { return "Minimal" }
            if total <= 9 { return "Mild" }
            if total <= 14 { return "Moderate" }
            if total <= 19 { return "Moderately Severe" }
            return "Severe"
        case .gad7:
            if total <= 4 { return "Minimal" }
            if total <= 9 { return "Mild" }
            if total <= 14 { return "Moderate" }
            return "Severe"
        }
    }
    
    init(type: AssessmentType) {
        self.type = type
        self.items = Array(repeating: 0, count: type == .phq9 ? 9 : 7)
    }
}

enum AssessmentType: String, Codable {
    case phq9 = "PHQ-9"
    case gad7 = "GAD-7"
}

// MARK: - Risk Assessment
struct RiskAssessment: Codable {
    var suicidalIdeation: IdeationType = .none
    var homicidalIdeation: IdeationType = .none
    var safetyPlanReviewed: Bool = false
    var crisisResourcesProvided: Bool = false
}

enum IdeationType: String, Codable, CaseIterable {
    case none = "Denied"
    case passive = "Passive"
    case active = "Active"
}

// MARK: - CPT Codes
struct CPTCode: Identifiable {
    var id: String { code }
    var code: String
    var description: String
}

let cptCodes: [CPTCode] = [
    CPTCode(code: "90832", description: "Psychotherapy, 16-37 min"),
    CPTCode(code: "90834", description: "Psychotherapy, 38-52 min"),
    CPTCode(code: "90837", description: "Psychotherapy, 53+ min"),
    CPTCode(code: "90847", description: "Family therapy with patient"),
    CPTCode(code: "90846", description: "Family therapy without patient"),
    CPTCode(code: "90853", description: "Group psychotherapy"),
    CPTCode(code: "90791", description: "Psychiatric diagnostic eval"),
    CPTCode(code: "96156", description: "Health behavior assessment")
]

// MARK: - Common Diagnoses
let commonDiagnoses: [Diagnosis] = [
    Diagnosis(code: "F32.0", name: "Major Depressive Disorder, Single Episode, Mild"),
    Diagnosis(code: "F32.1", name: "Major Depressive Disorder, Single Episode, Moderate"),
    Diagnosis(code: "F32.2", name: "Major Depressive Disorder, Single Episode, Severe"),
    Diagnosis(code: "F33.0", name: "Major Depressive Disorder, Recurrent, Mild"),
    Diagnosis(code: "F33.1", name: "Major Depressive Disorder, Recurrent, Moderate"),
    Diagnosis(code: "F33.2", name: "Major Depressive Disorder, Recurrent, Severe"),
    Diagnosis(code: "F41.1", name: "Generalized Anxiety Disorder"),
    Diagnosis(code: "F41.0", name: "Panic Disorder"),
    Diagnosis(code: "F40.10", name: "Social Anxiety Disorder"),
    Diagnosis(code: "F43.10", name: "PTSD, Unspecified"),
    Diagnosis(code: "F43.11", name: "PTSD, Acute"),
    Diagnosis(code: "F43.12", name: "PTSD, Chronic"),
    Diagnosis(code: "F43.21", name: "Adjustment Disorder with Depressed Mood"),
    Diagnosis(code: "F43.22", name: "Adjustment Disorder with Anxiety"),
    Diagnosis(code: "F43.23", name: "Adjustment Disorder, Mixed Anxiety/Depression"),
    Diagnosis(code: "F31.9", name: "Bipolar Disorder, Unspecified"),
    Diagnosis(code: "F31.81", name: "Bipolar II Disorder"),
    Diagnosis(code: "F42.2", name: "OCD, Mixed"),
    Diagnosis(code: "F50.00", name: "Anorexia Nervosa"),
    Diagnosis(code: "F50.2", name: "Bulimia Nervosa"),
    Diagnosis(code: "F50.81", name: "Binge Eating Disorder"),
    Diagnosis(code: "F60.3", name: "Borderline Personality Disorder"),
    Diagnosis(code: "F90.0", name: "ADHD, Inattentive Type"),
    Diagnosis(code: "F90.1", name: "ADHD, Hyperactive Type"),
    Diagnosis(code: "F90.2", name: "ADHD, Combined Type"),
    Diagnosis(code: "F10.10", name: "Alcohol Use Disorder, Mild"),
    Diagnosis(code: "F10.20", name: "Alcohol Use Disorder, Moderate"),
    Diagnosis(code: "F34.1", name: "Persistent Depressive Disorder"),
    Diagnosis(code: "F44.9", name: "Dissociative Disorder"),
    Diagnosis(code: "Z63.0", name: "Relationship Distress"),
    Diagnosis(code: "Z56.9", name: "Occupational Problem"),
    Diagnosis(code: "Z63.4", name: "Death of Family Member")
]

// MARK: - PHQ-9 Questions
let phq9Questions = [
    "Little interest or pleasure in doing things",
    "Feeling down, depressed, or hopeless",
    "Trouble falling/staying asleep, or sleeping too much",
    "Feeling tired or having little energy",
    "Poor appetite or overeating",
    "Feeling bad about yourself",
    "Trouble concentrating",
    "Moving/speaking slowly or being fidgety",
    "Thoughts of being better off dead or hurting yourself"
]

// MARK: - GAD-7 Questions
let gad7Questions = [
    "Feeling nervous, anxious, or on edge",
    "Not being able to stop or control worrying",
    "Worrying too much about different things",
    "Trouble relaxing",
    "Being so restless it's hard to sit still",
    "Becoming easily annoyed or irritable",
    "Feeling afraid something awful might happen"
]
