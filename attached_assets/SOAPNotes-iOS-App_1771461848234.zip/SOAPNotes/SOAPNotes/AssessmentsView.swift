import SwiftUI

struct AssessmentsView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        NavigationView {
            List {
                // Score Summary
                Section {
                    HStack(spacing: 20) {
                        ScoreCard(
                            title: "PHQ-9",
                            score: appState.currentNote.phq9.total,
                            maxScore: 27,
                            severity: appState.currentNote.phq9.severity,
                            color: phq9Color
                        )
                        
                        ScoreCard(
                            title: "GAD-7",
                            score: appState.currentNote.gad7.total,
                            maxScore: 21,
                            severity: appState.currentNote.gad7.severity,
                            color: gad7Color
                        )
                    }
                    .padding(.vertical, 8)
                    
                    // Item 9 Warning
                    if appState.currentNote.phq9.items[8] > 0 {
                        HStack {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundColor(.red)
                            Text("PHQ-9 Item 9 elevated (\(appState.currentNote.phq9.items[8])/3) - Address in Risk Assessment")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                        .padding(8)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(8)
                    }
                }
                
                // PHQ-9 Section
                Section(header: Label("PHQ-9 (Depression)", systemImage: "heart.text.square")) {
                    DatePicker("Date Administered",
                              selection: $appState.currentNote.phq9.date,
                              displayedComponents: .date)
                    
                    ForEach(0..<9, id: \.self) { index in
                        AssessmentItemRow(
                            index: index,
                            question: phq9Questions[index],
                            score: $appState.currentNote.phq9.items[index],
                            isHighlighted: index == 8
                        )
                    }
                }
                
                // GAD-7 Section
                Section(header: Label("GAD-7 (Anxiety)", systemImage: "waveform.path.ecg")) {
                    DatePicker("Date Administered",
                              selection: $appState.currentNote.gad7.date,
                              displayedComponents: .date)
                    
                    ForEach(0..<7, id: \.self) { index in
                        AssessmentItemRow(
                            index: index,
                            question: gad7Questions[index],
                            score: $appState.currentNote.gad7.items[index],
                            isHighlighted: false
                        )
                    }
                }
                
                // Scoring Guide
                Section(header: Text("Scoring Guide")) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Response Options:")
                            .font(.caption)
                            .fontWeight(.bold)
                        
                        ForEach(scoreGuide, id: \.0) { score, description in
                            HStack {
                                Text("\(score)")
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .frame(width: 20)
                                Text(description)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Clinical Measures")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { appState.lock() }) {
                        Image(systemName: "lock.fill")
                    }
                }
            }
            .onChange(of: appState.currentNote.phq9) { _ in appState.saveNote() }
            .onChange(of: appState.currentNote.gad7) { _ in appState.saveNote() }
        }
    }
    
    var phq9Color: Color {
        let score = appState.currentNote.phq9.total
        if score <= 4 { return .green }
        if score <= 9 { return .yellow }
        if score <= 14 { return .orange }
        return .red
    }
    
    var gad7Color: Color {
        let score = appState.currentNote.gad7.total
        if score <= 4 { return .green }
        if score <= 9 { return .yellow }
        if score <= 14 { return .orange }
        return .red
    }
    
    let scoreGuide = [
        (0, "Not at all"),
        (1, "Several days"),
        (2, "More than half the days"),
        (3, "Nearly every day")
    ]
}

struct ScoreCard: View {
    let title: String
    let score: Int
    let maxScore: Int
    let severity: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 8) {
            Text(title)
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(.secondary)
            
            Text("\(score)")
                .font(.system(size: 36, weight: .bold))
                .foregroundColor(color)
            
            Text("/\(maxScore)")
                .font(.caption)
                .foregroundColor(.secondary)
            
            Text(severity)
                .font(.caption2)
                .fontWeight(.semibold)
                .foregroundColor(.white)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(color)
                .cornerRadius(4)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(color.opacity(0.1))
        .cornerRadius(12)
    }
}

struct AssessmentItemRow: View {
    let index: Int
    let question: String
    @Binding var score: Int
    let isHighlighted: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top) {
                Text("\(index + 1).")
                    .font(.caption)
                    .fontWeight(.bold)
                    .foregroundColor(isHighlighted ? .red : .secondary)
                
                Text(question)
                    .font(.subheadline)
                    .foregroundColor(isHighlighted ? .red : .primary)
                
                if isHighlighted {
                    Text("(SI)")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                }
            }
            
            Picker("Score", selection: $score) {
                Text("0 - Not at all").tag(0)
                Text("1 - Several days").tag(1)
                Text("2 - More than half").tag(2)
                Text("3 - Nearly every day").tag(3)
            }
            .pickerStyle(SegmentedPickerStyle())
        }
        .padding(.vertical, 4)
        .background(isHighlighted ? Color.red.opacity(0.05) : Color.clear)
    }
}
