import SwiftUI

struct ExportView: View {
    @EnvironmentObject var appState: AppState
    @State private var showShareSheet = false
    @State private var showClearConfirm = false
    @State private var clearAfterExport = true
    
    var body: some View {
        NavigationView {
            List {
                // Preview Section
                Section(header: Label("Note Preview", systemImage: "doc.text.magnifyingglass")) {
                    ScrollView {
                        Text(appState.generateNoteText())
                            .font(.system(.caption, design: .monospaced))
                            .padding()
                    }
                    .frame(height: 300)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                }
                
                // Export Options
                Section(header: Label("Export Options", systemImage: "square.and.arrow.up")) {
                    Toggle(isOn: $clearAfterExport) {
                        VStack(alignment: .leading) {
                            Text("Clear After Export")
                                .font(.subheadline)
                            Text("Recommended for HIPAA - removes PHI after saving")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    Button(action: { showShareSheet = true }) {
                        HStack {
                            Image(systemName: "square.and.arrow.up")
                                .foregroundColor(.white)
                                .frame(width: 30, height: 30)
                                .background(Color.blue)
                                .cornerRadius(6)
                            
                            VStack(alignment: .leading) {
                                Text("Export Note")
                                    .fontWeight(.semibold)
                                Text("Share as text file")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                        }
                    }
                    .foregroundColor(.primary)
                }
                
                // New Note
                Section(header: Label("Start Fresh", systemImage: "arrow.counterclockwise")) {
                    Button(action: { showClearConfirm = true }) {
                        HStack {
                            Image(systemName: "trash")
                                .foregroundColor(.white)
                                .frame(width: 30, height: 30)
                                .background(Color.red)
                                .cornerRadius(6)
                            
                            VStack(alignment: .leading) {
                                Text("Clear All & Start New Note")
                                    .fontWeight(.semibold)
                                Text("Removes all current data")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            
                            Spacer()
                        }
                    }
                    .foregroundColor(.primary)
                }
                
                // Privacy Notice
                Section(header: Label("Privacy & Security", systemImage: "lock.shield")) {
                    VStack(alignment: .leading, spacing: 12) {
                        PrivacyRow(icon: "checkmark.shield.fill", color: .green, text: "Data stored locally with Keychain encryption")
                        PrivacyRow(icon: "checkmark.shield.fill", color: .green, text: "On-device speech recognition only")
                        PrivacyRow(icon: "checkmark.shield.fill", color: .green, text: "No cloud storage or transmission")
                        PrivacyRow(icon: "checkmark.shield.fill", color: .green, text: "Face ID / Touch ID protected")
                        PrivacyRow(icon: "exclamationmark.shield.fill", color: .orange, text: "Exported files are unencrypted - handle per your HIPAA policies")
                    }
                    .padding(.vertical, 8)
                }
                
                // Last Modified
                Section {
                    HStack {
                        Text("Last Modified")
                            .foregroundColor(.secondary)
                        Spacer()
                        Text(appState.currentNote.lastModified, style: .relative)
                            .foregroundColor(.secondary)
                    }
                    .font(.caption)
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Export")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { appState.lock() }) {
                        Image(systemName: "lock.fill")
                    }
                }
            }
            .sheet(isPresented: $showShareSheet) {
                ShareSheet(text: appState.generateNoteText()) {
                    if clearAfterExport {
                        appState.clearNote()
                    }
                }
            }
            .alert("Clear All Data?", isPresented: $showClearConfirm) {
                Button("Cancel", role: .cancel) { }
                Button("Clear", role: .destructive) {
                    appState.clearNote()
                }
            } message: {
                Text("This will permanently delete all current note data. Make sure you've exported first.")
            }
        }
    }
}

struct PrivacyRow: View {
    let icon: String
    let color: Color
    let text: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon)
                .foregroundColor(color)
                .font(.caption)
            Text(text)
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let text: String
    var onComplete: (() -> Void)?
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        // Create a temporary file
        let fileName = "SOAP_Note_\(Date().formatted(date: .numeric, time: .omitted)).txt"
        let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)
        
        do {
            try text.write(to: tempURL, atomically: true, encoding: .utf8)
        } catch {
            print("Error writing file: \(error)")
        }
        
        let controller = UIActivityViewController(
            activityItems: [tempURL],
            applicationActivities: nil
        )
        
        controller.completionWithItemsHandler = { _, completed, _, _ in
            if completed {
                onComplete?()
            }
            // Clean up temp file
            try? FileManager.default.removeItem(at: tempURL)
        }
        
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
