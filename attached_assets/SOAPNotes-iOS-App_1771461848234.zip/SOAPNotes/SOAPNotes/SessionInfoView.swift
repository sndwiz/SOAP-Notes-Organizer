import SwiftUI

struct SessionInfoView: View {
    @EnvironmentObject var appState: AppState
    @State private var showDiagnosisPicker = false
    @State private var diagnosisSearch = ""
    
    var filteredDiagnoses: [Diagnosis] {
        if diagnosisSearch.isEmpty {
            return commonDiagnoses
        }
        return commonDiagnoses.filter {
            $0.name.localizedCaseInsensitiveContains(diagnosisSearch) ||
            $0.code.localizedCaseInsensitiveContains(diagnosisSearch)
        }
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Label("Client Information", systemImage: "person.fill")) {
                    TextField("Client Name", text: $appState.currentNote.sessionInfo.clientName)
                        .textContentType(.name)
                    
                    DatePicker("Date of Birth",
                              selection: $appState.currentNote.sessionInfo.clientDOB,
                              displayedComponents: .date)
                }
                
                Section(header: Label("Session Details", systemImage: "calendar")) {
                    TextField("Provider Name", text: $appState.currentNote.sessionInfo.providerName)
                    
                    DatePicker("Session Date",
                              selection: $appState.currentNote.sessionInfo.sessionDate,
                              displayedComponents: .date)
                    
                    DatePicker("Start Time",
                              selection: $appState.currentNote.sessionInfo.startTime,
                              displayedComponents: .hourAndMinute)
                    
                    DatePicker("End Time",
                              selection: $appState.currentNote.sessionInfo.endTime,
                              displayedComponents: .hourAndMinute)
                    
                    TextField("Location", text: $appState.currentNote.sessionInfo.location)
                    
                    Toggle(isOn: $appState.currentNote.sessionInfo.isTelehealth) {
                        Label("Telehealth Session", systemImage: "video.fill")
                    }
                }
                
                Section(header: Label("Billing", systemImage: "dollarsign.circle")) {
                    Picker("CPT Code", selection: $appState.currentNote.sessionInfo.cptCode) {
                        ForEach(cptCodes) { cpt in
                            Text("\(cpt.code) - \(cpt.description)")
                                .tag(cpt.code)
                        }
                    }
                }
                
                Section(header: Label("Diagnosis (ICD-10)", systemImage: "stethoscope")) {
                    ForEach(appState.currentNote.sessionInfo.diagnoses) { diagnosis in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(diagnosis.code)
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundColor(.indigo)
                                Text(diagnosis.name)
                                    .font(.subheadline)
                            }
                            Spacer()
                            Button(action: {
                                removeDiagnosis(diagnosis)
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.red)
                            }
                        }
                    }
                    
                    Button(action: { showDiagnosisPicker = true }) {
                        Label("Add Diagnosis", systemImage: "plus.circle.fill")
                    }
                }
            }
            .navigationTitle("Session Info")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { appState.lock() }) {
                        Image(systemName: "lock.fill")
                    }
                }
            }
            .sheet(isPresented: $showDiagnosisPicker) {
                DiagnosisPickerSheet(
                    searchText: $diagnosisSearch,
                    filteredDiagnoses: filteredDiagnoses,
                    onSelect: { diagnosis in
                        addDiagnosis(diagnosis)
                        showDiagnosisPicker = false
                        diagnosisSearch = ""
                    },
                    onDismiss: {
                        showDiagnosisPicker = false
                        diagnosisSearch = ""
                    }
                )
            }
            .onChange(of: appState.currentNote.sessionInfo) { _ in
                appState.saveNote()
            }
        }
    }
    
    func addDiagnosis(_ diagnosis: Diagnosis) {
        if !appState.currentNote.sessionInfo.diagnoses.contains(where: { $0.code == diagnosis.code }) {
            appState.currentNote.sessionInfo.diagnoses.append(diagnosis)
        }
    }
    
    func removeDiagnosis(_ diagnosis: Diagnosis) {
        appState.currentNote.sessionInfo.diagnoses.removeAll { $0.code == diagnosis.code }
    }
}

struct DiagnosisPickerSheet: View {
    @Binding var searchText: String
    var filteredDiagnoses: [Diagnosis]
    var onSelect: (Diagnosis) -> Void
    var onDismiss: () -> Void
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Search diagnoses...", text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                List(filteredDiagnoses) { diagnosis in
                    Button(action: { onSelect(diagnosis) }) {
                        VStack(alignment: .leading) {
                            Text(diagnosis.code)
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.indigo)
                            Text(diagnosis.name)
                                .font(.subheadline)
                                .foregroundColor(.primary)
                        }
                    }
                }
            }
            .navigationTitle("Select Diagnosis")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel", action: onDismiss)
                }
            }
        }
    }
}
