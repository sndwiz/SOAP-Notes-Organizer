import SwiftUI
import LocalAuthentication

class AppState: ObservableObject {
    @Published var isUnlocked = false
    @Published var currentNote: SOAPNote = SOAPNote()
    @Published var showingExporter = false
    
    private let storageService = StorageService()
    
    init() {
        loadSavedNote()
    }
    
    func authenticate() {
        let context = LAContext()
        var error: NSError?
        
        if context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) {
            context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Unlock SOAP Notes") { success, error in
                DispatchQueue.main.async {
                    if success {
                        self.isUnlocked = true
                    }
                }
            }
        } else {
            // No biometrics, just unlock (device passcode is the backup)
            isUnlocked = true
        }
    }
    
    func lock() {
        saveNote()
        isUnlocked = false
    }
    
    func loadSavedNote() {
        if let saved = storageService.loadNote() {
            currentNote = saved
        }
    }
    
    func saveNote() {
        currentNote.lastModified = Date()
        storageService.saveNote(currentNote)
    }
    
    func clearNote() {
        currentNote = SOAPNote()
        storageService.deleteNote()
    }
    
    func generateNoteText() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        
        let timeFormatter = DateFormatter()
        timeFormatter.timeStyle = .short
        
        let info = currentNote.sessionInfo
        let diagnosisList = info.diagnoses.map { "\($0.name) (\($0.code))" }.joined(separator: "\n                ")
        
        let duration = Calendar.current.dateComponents([.minute], from: info.startTime, to: info.endTime).minute ?? 0
        
        return """
═══════════════════════════════════════════════════════════════════════════════
                         PSYCHOTHERAPY PROGRESS NOTE
═══════════════════════════════════════════════════════════════════════════════

SESSION INFORMATION
───────────────────────────────────────────────────────────────────────────────
Client Name:    \(info.clientName.isEmpty ? "[Not entered]" : info.clientName)
Date of Birth:  \(dateFormatter.string(from: info.clientDOB))
Provider:       \(info.providerName.isEmpty ? "[Not entered]" : info.providerName)
Date of Service: \(dateFormatter.string(from: info.sessionDate))
Start Time:     \(timeFormatter.string(from: info.startTime))
End Time:       \(timeFormatter.string(from: info.endTime))
Duration:       \(duration) minutes
Location:       \(info.location)\(info.isTelehealth ? " (Telehealth - Video)" : "")
CPT Code:       \(info.cptCode)

DIAGNOSIS/DIAGNOSES (ICD-10)
───────────────────────────────────────────────────────────────────────────────
                \(diagnosisList.isEmpty ? "[No diagnosis entered]" : diagnosisList)

═══════════════════════════════════════════════════════════════════════════════
                           CLINICAL MEASURES
═══════════════════════════════════════════════════════════════════════════════

PHQ-9 (Patient Health Questionnaire-9)
───────────────────────────────────────────────────────────────────────────────
Date Administered: \(dateFormatter.string(from: currentNote.phq9.date))
Total Score:       \(currentNote.phq9.total)/27
Severity Level:    \(currentNote.phq9.severity)
Item 9 (SI):       \(currentNote.phq9.items[8])/3 \(currentNote.phq9.items[8] > 0 ? "*** ELEVATED ***" : "")

GAD-7 (Generalized Anxiety Disorder-7)
───────────────────────────────────────────────────────────────────────────────
Date Administered: \(dateFormatter.string(from: currentNote.gad7.date))
Total Score:       \(currentNote.gad7.total)/21
Severity Level:    \(currentNote.gad7.severity)

═══════════════════════════════════════════════════════════════════════════════
                              SOAP NOTE
═══════════════════════════════════════════════════════════════════════════════

SUBJECTIVE
───────────────────────────────────────────────────────────────────────────────
\(currentNote.subjective.isEmpty ? "[No content entered]" : currentNote.subjective)

OBJECTIVE
───────────────────────────────────────────────────────────────────────────────
\(currentNote.objective.isEmpty ? "[No content entered]" : currentNote.objective)

Clinical Measures: PHQ-9 = \(currentNote.phq9.total) (\(currentNote.phq9.severity)), GAD-7 = \(currentNote.gad7.total) (\(currentNote.gad7.severity))

ASSESSMENT
───────────────────────────────────────────────────────────────────────────────
\(currentNote.assessment.isEmpty ? "[No content entered]" : currentNote.assessment)

PLAN
───────────────────────────────────────────────────────────────────────────────
\(currentNote.plan.isEmpty ? "[No content entered]" : currentNote.plan)

═══════════════════════════════════════════════════════════════════════════════
                           RISK ASSESSMENT
═══════════════════════════════════════════════════════════════════════════════
Suicidal Ideation:        \(currentNote.riskAssessment.suicidalIdeation.rawValue)
Homicidal Ideation:       \(currentNote.riskAssessment.homicidalIdeation.rawValue)
PHQ-9 Item 9 Score:       \(currentNote.phq9.items[8])/3
Safety Plan Reviewed:     \(currentNote.riskAssessment.safetyPlanReviewed ? "Yes" : "No")
Crisis Resources Provided: \(currentNote.riskAssessment.crisisResourcesProvided ? "Yes" : "N/A")

═══════════════════════════════════════════════════════════════════════════════

Provider Signature: _________________________________  Date: __________________

═══════════════════════════════════════════════════════════════════════════════

PRIVACY NOTICE: This document contains Protected Health Information (PHI) under
HIPAA. Handle according to your organization's privacy and security policies.
Generated locally on device - no cloud transmission.
"""
    }
}
