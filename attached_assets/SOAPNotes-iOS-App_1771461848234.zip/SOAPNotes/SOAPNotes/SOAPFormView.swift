import SwiftUI

struct SOAPFormView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        NavigationView {
            List {
                SOAPSectionView(
                    title: "Subjective",
                    icon: "person.wave.2",
                    color: .blue,
                    text: $appState.currentNote.subjective,
                    placeholder: "Client's self-reported experiences, symptoms, mood. Include direct quotes.",
                    tips: ["Include direct client quotes", "Document symptoms since last session", "Note mood changes"]
                )
                
                SOAPSectionView(
                    title: "Objective",
                    icon: "eye",
                    color: .green,
                    text: $appState.currentNote.objective,
                    placeholder: "Clinical observations, mental status, interventions used.",
                    tips: ["Document observable behaviors", "Note mental status", "List interventions (CBT, DBT, etc.)"]
                )
                
                SOAPSectionView(
                    title: "Assessment",
                    icon: "brain.head.profile",
                    color: .orange,
                    text: $appState.currentNote.assessment,
                    placeholder: "Clinical conceptualization, diagnosis support, progress.",
                    tips: ["Link to diagnosis", "Document functional impairment", "Note progress/regression"]
                )
                
                SOAPSectionView(
                    title: "Plan",
                    icon: "list.bullet.clipboard",
                    color: .purple,
                    text: $appState.currentNote.plan,
                    placeholder: "Treatment goals, homework, next session plan.",
                    tips: ["Document treatment goals", "Assign homework", "Note next appointment"]
                )
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("SOAP Note")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { appState.lock() }) {
                        Image(systemName: "lock.fill")
                    }
                }
            }
            .onChange(of: appState.currentNote.subjective) { _ in appState.saveNote() }
            .onChange(of: appState.currentNote.objective) { _ in appState.saveNote() }
            .onChange(of: appState.currentNote.assessment) { _ in appState.saveNote() }
            .onChange(of: appState.currentNote.plan) { _ in appState.saveNote() }
        }
    }
}

struct SOAPSectionView: View {
    let title: String
    let icon: String
    let color: Color
    @Binding var text: String
    let placeholder: String
    let tips: [String]
    
    @StateObject private var speechService = SpeechService()
    @State private var showTips = false
    
    var body: some View {
        Section {
            VStack(alignment: .leading, spacing: 12) {
                // Header with dictation button
                HStack {
                    Label(title, systemImage: icon)
                        .font(.headline)
                        .foregroundColor(color)
                    
                    Spacer()
                    
                    Button(action: {
                        if speechService.isRecording {
                            speechService.stopRecording()
                            text += " " + speechService.transcribedText
                        } else {
                            speechService.startRecording()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: speechService.isRecording ? "stop.fill" : "mic.fill")
                            Text(speechService.isRecording ? "Stop" : "Dictate")
                                .font(.caption)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(speechService.isRecording ? Color.red : color)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                    
                    Button(action: { showTips.toggle() }) {
                        Image(systemName: "questionmark.circle")
                            .foregroundColor(.gray)
                    }
                }
                
                // Recording indicator
                if speechService.isRecording {
                    HStack {
                        Circle()
                            .fill(Color.red)
                            .frame(width: 8, height: 8)
                        Text("Recording... Speak clearly")
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                    .padding(.vertical, 4)
                    
                    if !speechService.transcribedText.isEmpty {
                        Text(speechService.transcribedText)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(8)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                }
                
                // Tips
                if showTips {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(tips, id: \.self) { tip in
                            HStack(alignment: .top, spacing: 4) {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                    .font(.caption)
                                Text(tip)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .padding(8)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(8)
                }
                
                // Text editor
                ZStack(alignment: .topLeading) {
                    if text.isEmpty {
                        Text(placeholder)
                            .foregroundColor(.gray.opacity(0.5))
                            .padding(.horizontal, 4)
                            .padding(.vertical, 8)
                    }
                    
                    TextEditor(text: $text)
                        .frame(minHeight: 120)
                        .opacity(text.isEmpty ? 0.25 : 1)
                }
                
                // Clear button
                if !text.isEmpty {
                    HStack {
                        Spacer()
                        Button(action: { text = "" }) {
                            Label("Clear", systemImage: "trash")
                                .font(.caption)
                                .foregroundColor(.red)
                        }
                    }
                }
            }
        }
        .onDisappear {
            if speechService.isRecording {
                speechService.stopRecording()
                text += " " + speechService.transcribedText
            }
        }
    }
}
