import SwiftUI

struct RiskAssessmentView: View {
    @EnvironmentObject var appState: AppState
    
    var hasElevatedRisk: Bool {
        appState.currentNote.riskAssessment.suicidalIdeation != .none ||
        appState.currentNote.riskAssessment.homicidalIdeation != .none ||
        appState.currentNote.phq9.items[8] > 0
    }
    
    var body: some View {
        NavigationView {
            List {
                // Warning Banner
                if hasElevatedRisk {
                    Section {
                        HStack {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundColor(.red)
                                .font(.title2)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Elevated Risk Indicators")
                                    .font(.headline)
                                    .foregroundColor(.red)
                                Text("Document interventions and safety planning below")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical, 8)
                    }
                }
                
                // Suicidal Ideation
                Section(header: Label("Suicidal Ideation", systemImage: "exclamationmark.shield")) {
                    Picker("Status", selection: $appState.currentNote.riskAssessment.suicidalIdeation) {
                        ForEach(IdeationType.allCases, id: \.self) { type in
                            Text(type.rawValue).tag(type)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                    // PHQ-9 Item 9 Reference
                    HStack {
                        Text("PHQ-9 Item 9 Score:")
                            .font(.subheadline)
                        Spacer()
                        Text("\(appState.currentNote.phq9.items[8])/3")
                            .fontWeight(.bold)
                            .foregroundColor(appState.currentNote.phq9.items[8] > 0 ? .red : .green)
                    }
                    .padding(.vertical, 4)
                    
                    if appState.currentNote.riskAssessment.suicidalIdeation != .none {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Documentation Required:")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.red)
                            
                            BulletPoint("Nature and frequency of thoughts")
                            BulletPoint("Presence/absence of plan")
                            BulletPoint("Access to means")
                            BulletPoint("Protective factors identified")
                            BulletPoint("Interventions taken this session")
                        }
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(8)
                    }
                }
                
                // Homicidal Ideation
                Section(header: Label("Homicidal Ideation", systemImage: "exclamationmark.shield")) {
                    Picker("Status", selection: $appState.currentNote.riskAssessment.homicidalIdeation) {
                        Text("Denied").tag(IdeationType.none)
                        Text("Present").tag(IdeationType.passive)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                    if appState.currentNote.riskAssessment.homicidalIdeation != .none {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Documentation Required:")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.red)
                            
                            BulletPoint("Nature of ideation")
                            BulletPoint("Identified target (if any)")
                            BulletPoint("Tarasoff duty considered")
                            BulletPoint("Interventions taken")
                        }
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(8)
                    }
                }
                
                // Safety Planning
                Section(header: Label("Safety Planning", systemImage: "checkmark.shield")) {
                    Toggle(isOn: $appState.currentNote.riskAssessment.safetyPlanReviewed) {
                        VStack(alignment: .leading) {
                            Text("Safety Plan Reviewed")
                                .font(.subheadline)
                            Text("Document in Assessment/Plan sections")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    Toggle(isOn: $appState.currentNote.riskAssessment.crisisResourcesProvided) {
                        VStack(alignment: .leading) {
                            Text("Crisis Resources Provided")
                                .font(.subheadline)
                            Text("988 Suicide & Crisis Lifeline, etc.")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                // UTAH / SALT LAKE CITY RESOURCES (PRIMARY)
                Section(header: Label("Utah Crisis Lines (24/7)", systemImage: "phone.fill")) {
                    VStack(alignment: .leading, spacing: 16) {
                        ResourceRowFull(
                            name: "988 → Utah Crisis Line",
                            number: "988",
                            detail: "Routes to local Utah Crisis Line from UT area codes"
                        )
                        ResourceRowFull(
                            name: "Utah Crisis Line (Direct)",
                            number: "801-587-3000",
                            detail: "Huntsman Mental Health Institute - Salt Lake"
                        )
                        ResourceRowFull(
                            name: "Utah Crisis Line (Toll-Free)",
                            number: "1-800-273-8255",
                            detail: "Statewide, certified crisis workers"
                        )
                        ResourceRowFull(
                            name: "Utah Warm Line",
                            number: "1-833-SPEAKUT (773-2588)",
                            detail: "Peer support, 8am-11pm daily"
                        )
                    }
                    .padding(.vertical, 8)
                }
                
                Section(header: Label("Salt Lake Walk-In Crisis Care", systemImage: "building.2")) {
                    VStack(alignment: .leading, spacing: 16) {
                        WalkInResource(
                            name: "HMHI Crisis Care Center",
                            address: "501 Foothill Dr, Salt Lake City",
                            hours: "24/7 Walk-in, Adults 18+",
                            phone: "801-583-2500"
                        )
                        WalkInResource(
                            name: "Intermountain Behavioral Access Center",
                            address: "Multiple locations",
                            hours: "24/7 Walk-in, Adults 18+",
                            phone: "Call ahead for nearest location"
                        )
                    }
                    .padding(.vertical, 8)
                }
                
                Section(header: Label("Utah Youth & Teen Resources", systemImage: "person.2.fill")) {
                    VStack(alignment: .leading, spacing: 16) {
                        ResourceRowFull(
                            name: "SafeUT App",
                            number: "Download from App Store",
                            detail: "24/7 text/chat with licensed counselors for youth"
                        )
                        ResourceRowFull(
                            name: "HMHI Youth Crisis Care",
                            number: "801-587-3000",
                            detail: "Children & teen mental health emergencies"
                        )
                        ResourceRowFull(
                            name: "DCFS Child Abuse Hotline",
                            number: "1-855-323-3237",
                            detail: "Reporting suspected child abuse/neglect"
                        )
                    }
                    .padding(.vertical, 8)
                }
                
                Section(header: Label("Utah Domestic Violence", systemImage: "shield.fill")) {
                    VStack(alignment: .leading, spacing: 16) {
                        ResourceRowFull(
                            name: "YWCA Utah Crisis Line",
                            number: "801-537-8600",
                            detail: "24hr shelter & crisis, Salt Lake City"
                        )
                        ResourceRowFull(
                            name: "South Valley Services",
                            number: "801-255-1095",
                            detail: "West Jordan / South Salt Lake area"
                        )
                        ResourceRowFull(
                            name: "Utah DV LINKLine",
                            number: "1-800-897-LINK (5465)",
                            detail: "Statewide DV resources & referrals"
                        )
                        ResourceRowFull(
                            name: "Family Justice Center",
                            number: "801-236-3370",
                            detail: "Walk-in services M-Th 9-4, 310 E 300 S SLC"
                        )
                        ResourceRowFull(
                            name: "Rape Recovery Center",
                            number: "801-467-7273",
                            detail: "24hr sexual assault crisis line"
                        )
                    }
                    .padding(.vertical, 8)
                }
                
                Section(header: Label("Utah Substance Abuse", systemImage: "pills.fill")) {
                    VStack(alignment: .leading, spacing: 16) {
                        ResourceRowFull(
                            name: "VOA Detox Center",
                            number: "801-363-9400",
                            detail: "Adult detox, accepts uninsured"
                        )
                        ResourceRowFull(
                            name: "Valley Mental Health",
                            number: "888-949-4864",
                            detail: "Substance abuse treatment"
                        )
                        ResourceRowFull(
                            name: "211 Utah",
                            number: "211",
                            detail: "General resource connection including treatment"
                        )
                    }
                    .padding(.vertical, 8)
                }
                
                Section(header: Label("National Resources (Backup)", systemImage: "globe")) {
                    VStack(alignment: .leading, spacing: 16) {
                        ResourceRowFull(
                            name: "988 Suicide & Crisis Lifeline",
                            number: "988",
                            detail: "Call or text, 24/7 nationwide"
                        )
                        ResourceRowFull(
                            name: "Crisis Text Line",
                            number: "Text HOME to 741741",
                            detail: "Text-based crisis support"
                        )
                        ResourceRowFull(
                            name: "Veterans Crisis Line",
                            number: "988, Press 1",
                            detail: "Or text 838255"
                        )
                        ResourceRowFull(
                            name: "National DV Hotline",
                            number: "1-800-799-7233",
                            detail: "thehotline.org"
                        )
                        ResourceRowFull(
                            name: "SAMHSA Helpline",
                            number: "1-800-662-4357",
                            detail: "Substance abuse treatment referrals"
                        )
                        ResourceRowFull(
                            name: "Trans Lifeline",
                            number: "1-877-565-8860",
                            detail: "Peer support for trans community"
                        )
                        ResourceRowFull(
                            name: "Trevor Project (LGBTQ+ Youth)",
                            number: "1-866-488-7386",
                            detail: "Or text START to 678-678"
                        )
                    }
                    .padding(.vertical, 8)
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Risk Assessment")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { appState.lock() }) {
                        Image(systemName: "lock.fill")
                    }
                }
            }
            .onChange(of: appState.currentNote.riskAssessment) { _ in appState.saveNote() }
        }
    }
}

struct BulletPoint: View {
    let text: String
    
    init(_ text: String) {
        self.text = text
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "circle.fill")
                .font(.system(size: 6))
                .padding(.top, 6)
            Text(text)
                .font(.caption)
        }
    }
}

struct ResourceRow: View {
    let name: String
    let number: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(name)
                .font(.caption)
                .foregroundColor(.secondary)
            Text(number)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(.indigo)
        }
    }
}

struct ResourceRowFull: View {
    let name: String
    let number: String
    let detail: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(name)
                .font(.subheadline)
                .fontWeight(.semibold)
            
            Button(action: {
                // Make phone number callable
                let cleaned = number.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
                if let url = URL(string: "tel://\(cleaned)"), UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
            }) {
                HStack {
                    Image(systemName: "phone.fill")
                        .font(.caption)
                    Text(number)
                        .font(.callout)
                        .fontWeight(.bold)
                }
                .foregroundColor(.indigo)
            }
            
            Text(detail)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 4)
    }
}

struct WalkInResource: View {
    let name: String
    let address: String
    let hours: String
    let phone: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(name)
                .font(.subheadline)
                .fontWeight(.semibold)
            
            HStack(alignment: .top, spacing: 4) {
                Image(systemName: "mappin.circle.fill")
                    .foregroundColor(.red)
                    .font(.caption)
                Text(address)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            HStack(alignment: .top, spacing: 4) {
                Image(systemName: "clock.fill")
                    .foregroundColor(.green)
                    .font(.caption)
                Text(hours)
                    .font(.caption)
                    .foregroundColor(.green)
                    .fontWeight(.medium)
            }
            
            Button(action: {
                let cleaned = phone.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
                if let url = URL(string: "tel://\(cleaned)"), UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
            }) {
                HStack {
                    Image(systemName: "phone.fill")
                        .font(.caption)
                    Text(phone)
                        .font(.caption)
                }
                .foregroundColor(.indigo)
            }
        }
        .padding(.vertical, 4)
    }
}
