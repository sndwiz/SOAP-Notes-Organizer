# SOAP Notes - HIPAA-Compliant Therapy Documentation

A native iOS app for psychologists to create insurance-compliant SOAP notes with voice dictation. All data stays on the device - no cloud, no servers, no HIPAA violations.

## Features

### Privacy & Security (HIPAA-Compliant)
- ✅ **On-device speech recognition** - Audio never leaves the phone (iOS 13+)
- ✅ **Keychain encryption** - Data encrypted at rest using Apple's Secure Enclave
- ✅ **Face ID / Touch ID** - Biometric protection with passcode fallback
- ✅ **No cloud storage** - Zero data transmission
- ✅ **Auto-lock** - App locks when backgrounded
- ✅ **Clear after export** - Option to wipe PHI after saving note

### Clinical Features
- 📝 Full SOAP note structure (Subjective, Objective, Assessment, Plan)
- 🎤 Voice dictation for hands-free documentation
- 📊 PHQ-9 and GAD-7 with automatic scoring
- ⚠️ Risk assessment with safety planning prompts
- 🏷️ 30+ common ICD-10 diagnosis codes
- 💰 CPT code selection for billing
- 📤 Export to text file for EHR import

## Requirements

- macOS with Xcode 14+ installed
- Apple Developer account (free works for sideloading)
- iPhone running iOS 15+ with Face ID or Touch ID
- USB cable to connect iPhone to Mac

## Installation Instructions

### Step 1: Download and Open in Xcode

1. Download the `SOAPNotes` folder to your Mac
2. Open Xcode
3. Go to **File → New → Project**
4. Select **iOS → App** and click Next
5. Configure:
   - Product Name: `SOAPNotes`
   - Team: Select your Apple ID
   - Organization Identifier: `com.yourname` (anything works)
   - Interface: **SwiftUI**
   - Language: **Swift**
6. Click Next and save the project
7. **Delete** the auto-generated `ContentView.swift` file
8. **Drag and drop** all `.swift` files from the downloaded folder into your Xcode project
9. Replace the auto-generated `Info.plist` with the one from the download
10. Replace the `Assets.xcassets` folder with the one from the download

### Step 2: Configure Signing

1. In Xcode, click on the project name in the left sidebar (top item)
2. Select the **SOAPNotes** target
3. Go to **Signing & Capabilities** tab
4. Check **"Automatically manage signing"**
5. Select your **Team** (your Apple ID)
6. If you see errors, Xcode will guide you to fix them

### Step 3: Enable Required Capabilities

1. Still in **Signing & Capabilities**, click **+ Capability**
2. Add **Keychain Sharing** (for encrypted storage)
3. The app will work without this but adds extra security

### Step 4: Connect iPhone and Build

1. Connect your iPhone to your Mac via USB
2. On your iPhone, go to **Settings → Privacy & Security → Developer Mode** and enable it (iOS 16+)
3. Trust your Mac when prompted on iPhone
4. In Xcode, select your iPhone from the device dropdown (top of window)
5. Click the **Play button** (▶️) or press **Cmd + R**
6. First time: You may need to trust the developer on iPhone:
   - Go to **Settings → General → VPN & Device Management**
   - Tap your developer certificate and tap **Trust**
7. Run again - the app should install and launch!

### Step 5: Allow Permissions

On first launch, the app will ask for:
- **Face ID** - To protect client data
- **Microphone** - For voice dictation
- **Speech Recognition** - For transcription

Allow all three for full functionality.

## Usage

### Creating a Note

1. **Session Tab**: Enter client info, select diagnosis codes, set CPT code
2. **SOAP Tab**: Tap "Dictate" to voice record, or type manually
3. **Measures Tab**: Complete PHQ-9 and/or GAD-7 if administered
4. **Risk Tab**: Document safety assessment
5. **Export Tab**: Preview, export, and optionally clear data

### Voice Dictation Tips

- Speak clearly and at a normal pace
- The app uses **on-device recognition** so it works without internet
- Tap "Stop" when finished, text will be added to the section
- You can edit the text manually after dictation

### Exporting Notes

1. Go to Export tab
2. Review the preview
3. Tap "Export Note"
4. Choose how to save:
   - **Files app** - Save to iCloud or local storage
   - **Email** - Send to yourself or EHR inbox
   - **AirDrop** - Transfer to Mac for EHR copy/paste
5. If "Clear After Export" is on, data is wiped automatically

## Troubleshooting

### "App needs to be verified"
Go to Settings → General → VPN & Device Management → Trust the developer certificate

### Voice dictation not working
1. Check microphone permission in Settings → SOAP Notes
2. Make sure you're running iOS 13+ for on-device recognition
3. Try restarting the app

### App locks immediately
This is expected! The app locks when backgrounded for security. Use Face ID to unlock.

### Data disappeared
Data is stored in the device Keychain. If you:
- Deleted and reinstalled the app
- Reset your device
- Restored from a non-encrypted backup

The data will be gone. Always export before any of these actions.

## Privacy Notice

This app is designed with HIPAA compliance in mind:

- **No data leaves your device** unless you explicitly export it
- **Voice recognition is on-device** (requiresOnDeviceRecognition = true)
- **Storage uses iOS Keychain** with kSecAttrAccessibleWhenUnlockedThisDeviceOnly
- **No analytics, no tracking, no cloud services**

However, **you are responsible** for:
- Securing exported files according to your organization's policies
- Not leaving the app unlocked unattended
- Proper device security (passcode, auto-lock, etc.)
- Compliance with your state's specific requirements

## Technical Details

- **Platform**: iOS 15+
- **Framework**: SwiftUI
- **Storage**: iOS Keychain (hardware-encrypted)
- **Speech**: Apple Speech Framework with on-device recognition
- **Auth**: LocalAuthentication (Face ID / Touch ID)

## Support

This is a self-contained app with no external dependencies or services. For issues:
1. Check the Troubleshooting section above
2. Ensure all permissions are granted
3. Try deleting and reinstalling (note: data will be lost)

---

**Disclaimer**: This app is a tool to assist with documentation. It does not constitute legal or compliance advice. Consult with your organization's compliance officer regarding HIPAA requirements.
